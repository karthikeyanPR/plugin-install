<div class="wrap">
    <div id="ays-quiz-subscribe-email-page-main">
        <div class="ays-quiz-subscribe-email-page-info-header">
            <h1 class="ays-quiz-subscribe-email-page-info-header-text" style="text-align: center;">Grab your GIFT</h1>
        </div>
        <div class="ays-quiz-subscribe-email-page-info-box">
            <div class="ays-quiz-subscribe-email-page-info-box-header">Want a free addon for your <a href="https://ays-pro.com/wordpress/quiz-maker" target="_blank">Quiz Maker</a> plugin to make your experience more advanced and better?</div>
            <div class="ays-quiz-subscribe-email-page-info-box-content">
                <div class="ays-quiz-subscribe-email-page-info-box-conditions">Here are the conditions:</div>
                <ol>
                    <li>Add our link to your website (wherever you want) Here is the link: <a href="https://ays-pro.com/wordpress/quiz-maker" target="_blank">https://ays-pro.com/wordpress/quiz-maker</a></li>
                    <li>The link should be do-follow</li>
                    <li>Use the <strong>WordPress quiz plugin</strong> anchor text</li>
                    <li>Send the link of your website to our email. (<a href="mailto:info@ays-pro.com">info@ays-pro.com</a> or <a href="https://ays-pro.com/contact" target="_blank">contact form</a>)</li>
                    <li>Get the <a href="https://ays-pro.com/export-results-addon-for-quiz-maker" target="_blank">Export Results</a> addon as a gift. Export all the results of any of your quizzes and make your experience more advanced.</li>
                </ol>
            </div>
        </div>
    </div>
</div>